package com.capstone.workify

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.capstone.workify.databinding.ActivityMainBinding
import com.capstone.workify.ui.activity.ActivityFragment
import com.capstone.workify.ui.article.ArticleFragment
import com.capstone.workify.ui.home.HomeFragment
import com.capstone.workify.ui.settings.SettingsFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        replaceFragment(HomeFragment())

        binding.bottomNavigationView.background = null
        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> replaceFragment(HomeFragment())
                R.id.navigation_activity -> replaceFragment(ActivityFragment())
                R.id.navigation_article -> replaceFragment(ArticleFragment())
                R.id.navigation_settings -> replaceFragment(SettingsFragment())
                else -> false
            }
            true
        }

        binding.fabButton.setOnClickListener {
            // Handle FAB button click event here
            // For example, you could navigate to another fragment or start a new activity
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.frame_layout, fragment)
            commit()
        }
    }
}
